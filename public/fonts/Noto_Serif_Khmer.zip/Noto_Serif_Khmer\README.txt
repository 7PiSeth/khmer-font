Noto Serif Khmer Variable Font
==============================

This download contains Noto Serif Khmer as both a variable font and static fonts.

Noto Serif Khmer is a variable font with these axes:
  wdth
  wght

This means all the styles are contained in a single file:
  Noto_Serif_Khmer/NotoSerifKhmer-VariableFont_wdth,wght.ttf

If your app fully supports variable fonts, you can now pick intermediate styles
that aren’t available as static fonts. Not all apps support variable fonts, and
in those cases you can use the static font files for Noto Serif Khmer:
  Noto_Serif_Khmer/static/NotoSerifKhmer_ExtraCondensed-Thin.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_ExtraCondensed-ExtraLight.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_ExtraCondensed-Light.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_ExtraCondensed-Regular.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_ExtraCondensed-Medium.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_ExtraCondensed-SemiBold.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_ExtraCondensed-Bold.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_ExtraCondensed-ExtraBold.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_ExtraCondensed-Black.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_Condensed-Thin.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_Condensed-ExtraLight.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_Condensed-Light.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_Condensed-Regular.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_Condensed-Medium.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_Condensed-SemiBold.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_Condensed-Bold.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_Condensed-ExtraBold.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_Condensed-Black.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_SemiCondensed-Thin.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_SemiCondensed-ExtraLight.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_SemiCondensed-Light.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_SemiCondensed-Regular.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_SemiCondensed-Medium.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_SemiCondensed-SemiBold.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_SemiCondensed-Bold.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_SemiCondensed-ExtraBold.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer_SemiCondensed-Black.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer-Thin.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer-ExtraLight.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer-Light.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer-Regular.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer-Medium.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer-SemiBold.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer-Bold.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer-ExtraBold.ttf
  Noto_Serif_Khmer/static/NotoSerifKhmer-Black.ttf

Get started
-----------

1. Install the font files you want to use

2. Use your app's font picker to view the font family and all the
available styles

Learn more about variable fonts
-------------------------------

  https://developers.google.com/web/fundamentals/design-and-ux/typography/variable-fonts
  https://variablefonts.typenetwork.com
  https://medium.com/variable-fonts

In desktop apps

  https://theblog.adobe.com/can-variable-fonts-illustrator-cc
  https://helpx.adobe.com/nz/photoshop/using/fonts.html#variable_fonts

Online

  https://developers.google.com/fonts/docs/getting_started
  https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Fonts/Variable_Fonts_Guide
  https://developer.microsoft.com/en-us/microsoft-edge/testdrive/demos/variable-fonts

Installing fonts

  MacOS: https://support.apple.com/en-us/HT201749
  Linux: https://www.google.com/search?q=how+to+install+a+font+on+gnu%2Blinux
  Windows: https://support.microsoft.com/en-us/help/314960/how-to-install-or-remove-a-font-in-windows

Android Apps

  https://developers.google.com/fonts/docs/android
  https://developer.android.com/guide/topics/ui/look-and-feel/downloadable-fonts

License
-------
Please read the full license text (OFL.txt) to understand the permissions,
restrictions and requirements for usage, redistribution, and modification.

You can use them in your products & projects – print or digital,
commercial or otherwise.

This isn't legal advice, please consider consulting a lawyer and see the full
license for all details.
